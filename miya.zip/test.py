import os
hostname = "192.168.0.1" #example

response = os.system("ping " + hostname+" -n 1000 -l 65500 ")

#and then check the response...
if response == 0:
  print (hostname, 'is up!')
else:
  print (hostname, 'is down!')
import random
import pygame
import pyautogui
import time
pygame.init()
#sound
Start_sound = pygame.mixer.Sound("./sound/start.wav")
Over_sound = pygame.mixer.Sound("./sound/morse.mp3")
margaya_bc = pygame.mixer.Sound("./sound/margaya_bc.mp3")
orebaba = pygame.mixer.Sound("./sound/ore_baba.mp3")
Restart_sound = pygame.mixer.Sound("./sound/restart.wav")
jidsi_sound=pygame.mixer.Sound("./sound/jidsi.mp3")
gan1=pygame.mixer.Sound("./sound/gan1.mp3")
y100=pygame.mixer.Sound("./sound/100.mp3")
y200=pygame.mixer.Sound("./sound/200.mp3")
y300=pygame.mixer.Sound("./sound/300.mp3")




gan1_bolar_number=random.randint(100,700)


gan1_chek=True
game_windo=pygame.display.set_mode((0,0),pygame.FULLSCREEN)
pygame.display.set_caption("Miya")
programIcon=pygame.image.load("./grafix/main_player.png")
pygame.display.set_icon(programIcon)
pygame.display.update()
Game_end=False
Game_over=False
clock = pygame.time.Clock()
windo_x, windo_y = game_windo.get_size()
#image
loding_screen=pygame.transform.scale(pygame.image.load("./grafix/start_screen.png"),(windo_x,windo_y)).convert_alpha()
die_screen=pygame.transform.scale(pygame.image.load("./grafix/die_screen.png"),(windo_x,windo_y)).convert_alpha()
sean1=pygame.image.load("./grafix/sean.jpg")
sean1=pygame.transform.scale(sean1,(windo_x,windo_y/2+100)).convert_alpha()
sean=pygame.image.load("./grafix/sean1.jpg")
sean=pygame.transform.scale(sean,(windo_x,windo_y/2)).convert_alpha()
player=pygame.transform.scale(pygame.image.load("./grafix/main_player.png"),(70,70)).convert_alpha()
p_y=windo_y/2-200
tree=[pygame.transform.scale(pygame.image.load("./grafix/tree1.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree2.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree3.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree4.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree1.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree2.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree3.png"),(70,70)).convert_alpha(),pygame.transform.scale(pygame.image.load("./grafix/tree4.png"),(70,70)).convert_alpha()]
treepos=[random.randint(0,windo_x),random.randint(0,windo_x),random.randint(0,windo_x),random.randint(0,windo_x),random.randint(0,windo_x),random.randint(0,windo_x),random.randint(0,windo_x),random.randint(0,windo_x)]
e_plane=pygame.transform.scale(pygame.image.load("./grafix/e_plane.png"),(70,70)).convert_alpha()
valocity=10
p_x=20
show_highscor_key_chek=0
upAndDown=2
my_font = pygame.font.SysFont('Comic Sans MS', 30)
score=0.0
show_high_score_chek=False
scoreUbdateSpeed=0.05
hight_score_file=open("./accest/high_score.txt","r+")
die_screen_image_pos_y=windo_y
high_score=my_font.render("Test",True,(255,4,0))
hight_score=hight_score_file.read()
exit_text=my_font.render("Exit",True,(0,0,255))
exit_text_width=windo_x/2
exit_text_hight=windo_y/2+120
jidsi_chek=True
restart_text=my_font.render("Restart",True,(0,0,255))
print(hight_score)
#game looop
enemy=[[random.randint(windo_x+70,windo_x+1000),random.randint(20,windo_y/2-70)],[random.randint(windo_x+70,windo_x+1000),random.randint(20,windo_y/2-70)],[random.randint(windo_x+70,windo_x+1000),random.randint(20,windo_y/2-70)],[random.randint(windo_x+70,windo_x+1000),random.randint(20,windo_y/2-70)],[random.randint(windo_x+70,windo_x+1000),random.randint(20,windo_y/2-70)]]
start_screen=True
Over_play_Sound=True
chek_pos_for_game_over=0
y100_chek=True
y200_chek=True
y300_chek=True

while Game_end ==False:
    mouse_x,mouse_y = pygame.mouse.get_pos()
    if int(str(score).split(".")[0]) == 1000:
        if jidsi_chek == True: 
            pygame.mixer.Sound.play(jidsi_sound)
            jidsi_chek=False
    if int(str(score).split(".")[0]) == gan1_bolar_number:
        if gan1_chek == True: 
            pygame.mixer.Sound.play(gan1)
            gan1_chek=False
    if int(str(score).split(".")[0]) == 100:
        if y100_chek == True: 
            pygame.mixer.Sound.play(y100)
            y100_chek=False
    if int(str(score).split(".")[0]) == 200:
        if y200_chek == True: 
            pygame.mixer.Sound.play(y200)
            y200_chek=False
    if int(str(score).split(".")[0]) == 300:
        if y300_chek == True: 
            pygame.mixer.Sound.play(y300)
            y300_chek=False
        

    score=score+scoreUbdateSpeed
    score_text = my_font.render("Score: "+str(score).split(".")[0], False, (0, 0, 0))
    #Key event
    keys = pygame.key.get_pressed() 
    if keys[pygame.K_h] and keys[pygame.K_s]:
        show_high_score_chek=True
    if keys[pygame.K_w] or keys[pygame.K_UP]:
        if p_y >20:
            p_y-=upAndDown
    if keys[pygame.K_s] or keys[pygame.K_DOWN]:
        if p_y <windo_y/2-70:
            p_y+=upAndDown
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Game_end = True
        # if event.type == pygame.KEYDOWN:
        #     if show_highscor_key_chek==0:
        #         if event.key == pygame.K_h:
        #             show_highscor_key_chek=1
        #     if show_highscor_key_chek ==1:
        #         if event.key==pygame.K_s:
        #             show_high_score_chek=True
        #         else:
        #             show_high_score_chek=0
            if event.key == pygame.K_ESCAPE:
                Game_end=True
                print("game Ses. Ehon coker pani ar naker pani :(")
    

    game_windo.fill((0,0,0))
    game_windo.blit(sean1,(0,0))
    game_windo.blit(sean,(0,windo_y/2+100))
    game_windo.blit(score_text, (windo_x/2,5))
    game_windo.blit(player,(p_x,p_y))
    if show_high_score_chek==True:
        game_windo.blit(high_score,(0,10))
    
    

    #Tree ba gass
    for i in range(len(tree)):
        game_windo.blit(tree[i],(treepos[i],windo_y/2+50))
        treepos[i]=treepos[i]-valocity
        if treepos[i] < -0:
            treepos[i]=random.randint(windo_x+100,windo_x+200)
    for w in range(len(enemy)):
        game_windo.blit(e_plane,(enemy[w][0],enemy[w][1]))
        enemy[w][0]=enemy[w][0]-valocity
        if enemy[w][0] < -70:
            enemy[w][0]=random.randint(windo_x+70,windo_x+1000)
            enemy[w][1]=random.randint(20,windo_y/2-50)
        if abs(enemy[w][0]-p_x) < 20 and abs(enemy[w][1]-p_y) < 40:

            Game_over=True
            if Over_play_Sound==True:
                pygame.mixer.Sound.play(random.choice([Over_sound,margaya_bc,orebaba]))
                Over_play_Sound=False
    #game over
    if Game_over==True:
        if chek_pos_for_game_over==0:
            pyautogui.moveTo(exit_text_width+5, exit_text_hight+55)
            chek_pos_for_game_over=1
        print(abs(exit_text_width-mouse_x))
        valocity=0
        upAndDown=0
        scoreUbdateSpeed=0.0
        game_windo.blit(die_screen,(0,die_screen_image_pos_y))
        game_windo.blit(exit_text,(exit_text_width,exit_text_hight))
        if abs(exit_text_width-mouse_x) < 25 and abs(exit_text_hight-mouse_y) < 25:
            exit_text=my_font.render("Exit",True,(255,0,0))
            if pygame.mouse.get_pressed()[0]:
                Game_end=True
        else:
            exit_text=my_font.render("Exit",True,(0,0,255))
        
        game_windo.blit(restart_text,(exit_text_width,exit_text_hight+50))
        if abs(exit_text_width-mouse_x) < 25 and abs(exit_text_hight+50-mouse_y) < 25:
            restart_text=my_font.render("Restart",True,(255,0,0))
            if pygame.mouse.get_pressed()[0]:
                valocity=5
                upAndDown=2 
                scoreUbdateSpeed=0.05
                score=0.0
                Over_play_Sound=True
                for w in enemy:
                    w[0]=random.randint(windo_x+70,windo_x+1000)
                Game_over=False
                die_screen_image_pos_y=windo_y
                chek_pos_for_game_over=0
        else:
            restart_text=my_font.render("Restart",True,(0,0,255))


        if die_screen_image_pos_y > 1:
            die_screen_image_pos_y-=30
        else:
            die_screen_image_pos_y=0
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        valocity=5
                        upAndDown=2 
                        scoreUbdateSpeed=0.05
                        score=0.0
                        chek_pos_for_game_over=0
                        Over_play_Sound=True
                        for w in enemy:
                            w[0]=random.randint(windo_x+70,windo_x+1000)
                        Game_over=False
                        die_screen_image_pos_y=windo_y
                        pygame.mixer.Sound.play(Restart_sound)
                    elif event.key == pygame.K_ESCAPE:
                        Game_end = True
    #start screen
    if start_screen==True:
        scoreUbdateSpeed=0.0
        game_windo.blit(loding_screen,(0,0))
        valocity=0
        upAndDown=0
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    valocity=5
                    upAndDown=2 
                    start_screen=False
                    scoreUbdateSpeed=0.05
                    score=0.0
                    pygame.mixer.Sound.play(Start_sound)
                    for w in enemy:
                        w[0]=random.randint(windo_x+70,windo_x+1000)
    if int(hight_score) < int(str(score).split(".")[0]):
        hight_score_file=open("./accest/high_score.txt","w")
        hight_score_file.write(str(score).split(".")[0])
                
    pygame.display.update()